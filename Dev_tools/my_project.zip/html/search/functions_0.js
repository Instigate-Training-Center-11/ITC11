var searchData=
[
  ['clear_24',['clear',['../classList.html#a3fad6292bd5126eeb437317383338cea',1,'List']]]
];
