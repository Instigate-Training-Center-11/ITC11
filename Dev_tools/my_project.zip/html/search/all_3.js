var searchData=
[
  ['node_6',['Node',['../classNode.html',1,'Node'],['../classNode.html#afaf7aeb5007766646b7cf2c4f2222451',1,'Node::Node()']]]
];
